<?php 
ob_start();
session_start();
    require 'user/clean.php';
    function basePage($data){
         echo basename($_SERVER["REQUEST_URI"]) == $data?"uk-active":"" ;
    }
 ?>
<!DOCTYPE html>
<html lang="zxx" dir="ltr">

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Standard Meta -->
    <meta charset="utf-8">
    <meta name="description" content="Premium HTML5 Template by Indonez">
    <meta name="keywords" content="blockit, uikit3, indonez, handlebars, scss, vanilla javascript">
    <meta name="author" content="Indonez">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#e9e8f0" />
    <!-- Site Properties -->
    <title>CCITraders - Your One Stop Forex Centre</title>
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
    <!-- Critical preload -->
    <link rel="preload" href="js/vendors/uikit.min.js" as="script">
    <link rel="preload" href="css/vendors/uikit.min.css" as="style">
    <link rel="preload" href="css/style.css" as="style">
  
    <!-- Favicon and apple icon --> 
    <link rel="apple-touch-icon-precomposed" href="img/favicon.png">
    <!-- Stylesheet -->
    <link rel="stylesheet" href="css/vendors/uikit.min.css">
    <link rel="stylesheet" href="css/style.css">

    <style>
        .mt-40{
            margin-top: 40px !important;
        }
    </style>
</head>