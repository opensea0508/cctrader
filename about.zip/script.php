<!-- Javascript -->
<script src="js/vendors/uikit.min.js"></script>
    <script src="js/vendors/indonez.min.js"></script>
    <script src="../../../widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js" defer></script>
    <script src="js/config-theme.js"></script>
    <?php if(isset($_SESSION['msg'])) unset($_SESSION['msg'])  ?>