
<footer>
        <!-- footer content begin -->
        <div class="uk-section uk-section-primary uk-padding-large uk-padding-remove-horizontal uk-margin-medium-top">
        <div class="uk-container uk-lightz">
            <div class="uk-grid uk-margin-large-top">
                <div class="uk-width-1-4@l uk-width-1-5@m uk-width-1-3@s">
                    <ul class="uk-list">
                        <li><a href="home">Home</a></li>
                        <li><a href="about">About Us</a></li>
                        <li><a href="why-us">Why Us</a></li>
                        <li><a href="contact-us">Contact Us</a></li>
                    </ul>
                </div>
                <div class="uk-width-1-4@l uk-width-1-5@m uk-width-1-3@s">
                    <ul class="uk-list">
                        <li><a href="how-it-works">How it Works</a></li>
                        <li><a href="privacy">Privacy Policy</a></li>
                        <li><a href="terms">Terms</a></li>
                        <li><a href="risk">Risk Disclosure</a></li>
                    </ul>
                </div>
                <div class="uk-width-1-4@l uk-width-1-5@m uk-width-1-3@s">
                    <ul class="uk-list">
                        <li><a href="seminar">Seminar</a></li>
                        <li><a href="training">Training</a></li>
                        <li><a href="office/live-account">Live Account</a></li>
                    </ul>
                </div>
                <div class="uk-width-1-4@l uk-width-2-5@m uk-width-1-1@s">
                    <div class="uk-align-right idz-footer-adjust">
                        <h5>Follow Us on Social Media</h5>
						<a class="uk-icon-button  uk-margin-small-right" href="https://web.facebook.com/ctrad.ctrad" target="_blank"><i class="fab fa-facebook"></i></a>
						<a class="uk-icon-button  uk-margin-small-right" href="#"><i class="fab fa-twitter"></i></a>
						<a class="uk-icon-button  uk-margin-small-right" href="#"><i class="fab fa-linkedin"></i></a>
						<a class="uk-icon-button  uk-margin-small-right" href="#"><i class="fab fa-youtube"></i></a>
                    </div> 
                </div>
                
                 
            </div>
        </div>

            <div class="uk-container">
                 
                <div class="uk-grid uk-flex uk-flex-center uk-margin-large-top" data-uk-grid>
                    <div class="uk-width-5-6@m uk-margin-bottom">
                        <div class="in-footer-warning in-margin-top-20@s">
                            <h5 class="uk-text-small uk-text-uppercase"><span>Risk Warning</span></h5>
                            <p class="uk-text-small">Risk warning: CCI traders, (Employees) may trade in derivatives for their own accounts or for the accounts of others. Our trading results may vary; there is no absolute guaranteed freedom of profits. Our trades can closed at profits some can close at loses, therefore investors and traders should understand the risks involved in taking leveraged positions and must assume responsibility for the risks associated with such investments and for their results, also traders and investors should use only genuine risk capital. Trading and investing is not suitable for all members of the public. Trading CFDs carries a level of risk since leverage can work both to your advantage and disadvantage. You should consider your financial situation and condition before making any investment or trading, if possible seek for independent financial adviser. CCI traders are compensated for their services through profits commission from any trade, and Profit sharing are subject to a daily, weekly monthly or yearly performance .Signing up is totally free. </p>
                        </div>
                    </div>
                    <div class="uk-width-1-2@m in-copyright-text">
                        <p> Copyright &copy; <?php echo date("Y") ?> CCI Traders. All Rights Reserved.</p>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- footer content end -->
        <!-- module totop begin -->
        <div class="uk-visible@m">
            <a href="#" class="in-totop fas fa-chevron-up" data-uk-scroll></a>
        </div>
        <!-- module totop begin -->
    </footer>