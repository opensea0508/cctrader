
        <div class="tap-top"><i class="fa fa-arrow-up"></i></div>
        <footer class="footer">
            <div class="container-fluid">
            <div class="row">
                <div class="col-12 footer-copyright">
                <p class="mb-0">Copyright <?php echo date("Y") ?> © CCI Traders All rights reserved.</p>
                </div>
                
            </div>
            </div>
        </footer>