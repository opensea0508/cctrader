<?php include 'head.php';
$ref = bin2hex(random_bytes(11));
 ?>

  <body class="wide" >
   
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
    <?php include 'header.php' ?>
      
      <!-- Page Body Start-->
      <div class="page-body-wrapper sidebar-icon">
        <!-- Page Sidebar Start-->
    <?php include 'aside.php' ?>
        
        <!-- Page Sidebar Ends-->
        <div class="page-body porject-dash">
          <div class="container-fluid">
            <div class="page-header dash-breadcrumb">
              <div class="row">
                <div class="col-6"> </div>
                <div class="col-6">
                  <div class="breadcrumb-sec">
                    <ul class="breadcrumb"> 
                      <li class="breadcrumb-item">Dashboard</li> 
                      <li class="breadcrumb-item">User Details</li> 
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row ">
              <div class="col-xl-12">
                <div class="row">
                  <div class="col-xl-12 col-sm-6">
                    <div class="card">
                      <div class="card-body">
                        <?php echo isset($_SESSION['msg'])?$_SESSION['msg']:"" ?>
                        <div class="row">

                        <div class="col-md-6"> <h4>User Details</h4></div>
                        <div class="col-md-6 mb-2 " style="text-align:right">
                            <!-- <a href="javascript:void(0)" class="btn btn-primary">Trade Monitor Room link.</a> -->
                        </div>
                      
                       
                      <hr>
                      <?php 
                        
                        $sql = runQuery("SELECT * FROM dregister WHERE dlevel='user' ORDER BY id DESC LIMIT 200");
                        if(numRows($sql)>0){
                    ?>
                          <div class="col-md-6">
                              
                   
                      <div class="table-responsives" style="min-height: 250px;">
                        <table class="table">
                          
                            

                          <?php  $row=fetchAssoc($sql) ?>
                            <tr> 
                                <th>Fullname</th>
                                <td><?php echo $row['dfname']  ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo $row['dphone']  ?></td>
                            </tr>
                            <tr>
                                <th>Phone</th>
                                <td><?php echo $row['dphone']  ?></td>
                            </tr>
                            <tr>
                                <th>Country</th>
                                <td><?php echo $row['dcountry']  ?></td>
                            </tr>
                            <tr>
                                <th>State</th>
                                <td><?php echo $row['dstate']  ?></td>
                            </tr>
                            <tr>
                                <th>City</th>
                                <td><?php echo $row['dcity']  ?></td>
                            </tr>

                            <tr>
                                <th>Wallet Address</th>
                                <td><?php echo $row['dwalletAddress']  ?></td>
                            </tr>

                            <tr>
                                <th colspan="2" class="text-center">Account Details</th>
                            </tr>
                                
                            <tr>
                                <th>Account Name</th>
                                <td><?php echo $row['daccName']  ?></td>
                            </tr>

                            <tr>
                                <th>Account Number</th>
                                <td><?php echo $row['daccNum']  ?></td>
                            </tr>

                            <tr>
                                <th>Bank Name</th>
                                <td><?php echo $row['dbank']  ?></td>
                            </tr>
                                
 
                        </table>
                      </div>



                      



                      </div>
                        <div class="col-md-6">
                            <h6>Document Upload</h6>
                            <p>Vesrification Status: <?php echo ucfirst($row['dvastatus'])  ?></p>
                            <hr>

                            <?php  if(!empty($row['dutility'])){  ?>
                                <img src="../user/files/<?php echo $row['dutility']  ?>.jpg" alt="">
                                <hr>
                            <?php } if(!empty($row['dfront'])){  ?>
                                <img src="../user/files/<?php echo $row['dfront']  ?>.jpg" alt="">
                                <hr>
                            <?php } if(!empty($row['dback'])){  ?>
                                <img src="../user/files/<?php echo $row['dback']  ?>.jpg" alt="">
                                <hr>
                            <?php }  ?>

                            <form action="updatelink" method="post">
                                <div class="form-group">
                                    <label for="">Trade Monitor Room link. </label>
                                    <input type="text" value="<?php echo $row['turl']  ?>" name="link" required placeholder="Enter Trade Monitor Room link. " class="form-control">
                                </div>
                                <input type="hidden" name="id" value="<?php echo $row['userid']  ?>">
                                <input type="hidden" name="email" value="<?php echo $row['demail']  ?>">
                                <button type="submit" name="linkSave" class="btn-primary btn w-100" >Submit Link</button>
                            </form>
                                <hr>
                        </div>
                        <div class="col-md-12" style="text-align:right ;"> 

                            <?php if($row['dvastatus']=='pending'){ ?>
                            <a class="btn btn-info" data-id="<?php echo $row['userid']  ?>" data-email="<?php echo $row['demail']  ?>" id="verifyAccount" href="javascript:void(0)">Verify Account</a>
                            <?php } ?>

                                <?php if($row['dstatus']=='active'){ ?>
                                <a class="btn btn-danger" data-id="<?php echo $row['userid']  ?>" data-email="<?php echo $row['demail']  ?>" data-status="banned" id="banUser" href="javascript:void(0)">Ban User</a>
                                <?php }else{ ?>
                                <a class="btn btn-danger" data-id="<?php echo $row['userid']  ?>" data-email="<?php echo $row['demail']  ?>" data-status="active" id="banUser" href="javascript:void(0)">Unban User</a>
                                <?php } ?>
                        </div>
                      </div>

                      
                      </div>
                      <?php } ?>
                    </div>
                  </div>
                  
                
                  
                </div>
              </div>
             
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>
        <!-- tap on top starts--> 
        <!-- tap on tap ends-->
        <!-- footer start-->
    <?php include 'footer.php' ?>
        
      </div>
    </div>
   
    <?php include 'script.php' ?> 


        
  </body>
 
</html>