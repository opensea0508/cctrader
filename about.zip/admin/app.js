$(document).ready(function(){ 
    var userArray, text;

    $(document).on("click", "#banUser", function(){
        userArray = {
            'userid':$(this).attr('data-id'),
            "email":$(this).attr('data-email'),
            "status":$(this).attr('data-status')
        };
        let status = userArray.status =="banned"?"Banned!":"Activated!";
        text = 'Press yes button to continue...'
        newMagic("Are you sure?", text, 'ajax-success', 'Ban', userArray, status,'');
    })

    $(document).on("click", "#approveReq", function(){
        userArray = {
            'id':$(this).attr('data-id'),
            'userid':$(this).attr('data-uid'),
            "email":$(this).attr('data-email'),
            "status":$(this).attr('data-status')
        };
        let status = userArray.status =="approve"?"Approved!":"Rejected!";
        text = 'Press yes button to continue...'
        newMagic("Are you sure?", text, 'ajax-success', 'approveReq', userArray, status,'');
    })

    $(document).on("click", "#verifyAccount", function(){
        userArray = { 
            'userid':$(this).attr('data-id'),
            "email":$(this).attr('data-email')
        }; 
        let status = "Verified!";
        text = 'Press yes button to continue...'
        newMagic("Are you sure?", text, 'ajax-success', 'verifyAccount', userArray, status,'');
    })



})






function newMagic(sweetTitle, sweetText, dataPost, dataTitle, dataArray, dataSuccess, reLoad='no', retunLink='') {
        swal({
            title: sweetTitle,
            text: sweetText,
            icon: "warning",
            buttons: ["No", "Yes!"],
            // dangerMode: true, 
        })
        .then((result) => { 
            if (result){        
                $.ajax({
                    url:dataPost,
                    method:"POST",                    
                    data:{Message:dataTitle, id:dataArray},        
                    success:function(){
                        setInterval(function(){
                            if(reLoad =='no'){
                                window.location.assign(retunLink);
                            }else{
                                window.location.reload();
                            }
                        },2000);             
                    }
                }) .done(function(){ 
                    swal({
                        title:dataSuccess,
                        icon: "success"
                    });
                }) .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                });
            }


              
        })
}

