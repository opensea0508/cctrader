<?php

require '../user/clean.php';
$code = bin2hex(random_bytes(12));
$folder = 'files';

function updateReg($id, $email, $row, $rowRes){
    runQuery("UPDATE dregister SET $row='$rowRes' WHERE userid='$id' AND demail='$email' "); 
}
function deleteFire($tableName, $position){
  runQuery("DELETE FROM $tableName WHERE  $position "); 
}
function updateFire($tableName, $rowSet, $position){
  runQuery("UPDATE $tableName SET $rowSet WHERE  $position "); 
}

if(isset($_POST['Message']) AND $_POST['Message']='verifyAccount' ){
  $id = clean($_POST['id']['userid']);
  $email = clean($_POST['id']['email']); 
  updateReg($id, $email, 'dvastatus', 'Verified');
  updateReg($id, $email, 'dvstatus', 'Verified');
}

if(isset($_POST['Message']) AND $_POST['Message']='Ban' ){
  $id = clean($_POST['id']['userid']);
  $email = clean($_POST['id']['email']);
  $status = clean($_POST['id']['status']) =="banned"?"banned":"active";
  updateReg($id, $email, 'dstatus', $status);
}

if(isset($_POST['Message']) AND $_POST['Message']='approveReq' ){
  $id = clean($_POST['id']['id']);
  $userid = clean($_POST['id']['userid']);
  $email = clean($_POST['id']['email']);
  $status = clean($_POST['id']['status']) =="approve"?"Approved":"Rejected";
  $kyc = clean($_POST['id']['status']) =="approve"?"yes":"no";
  if($kyc=='yes'){
    //send approval mail
    $test = './kycMail.php'; 
  }else{
    //send rejected mail
    $test = './kycMail2.php'; 

  }
  $name = userInfo($userid, $email,'dfname');
  include './kycMailApi.php';
  updateReg($userid, $email, 'dkyc', $kyc);
  updateFire('dkyc',"dstatus='$status'", "id='$id'");
}



