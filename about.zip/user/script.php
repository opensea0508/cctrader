 <!-- latest jquery-->
 <script src="./assets/js/jquery-3.5.1.min.js"></script>
    <!-- feather icon js-->
    <script src="./assets/js/icons/feather-icon/feather.min.js"></script>
    <script src="./assets/js/icons/feather-icon/feather-icon.js"></script>
    <!-- Sidebar jquery-->
    <script src="./assets/js/sidebar-menu.js"></script>
    <script src="./assets/js/config.js">   </script>
    <!-- Bootstrap js-->
    <script src="./assets/js/bootstrap/popper.min.js"></script>
    <script src="./assets/js/bootstrap/bootstrap.min.js"></script>
    <!-- Plugins JS start-->
     
    <script src="./assets/js/prism/prism.min.js"></script>
    <script src="./assets/js/clipboard/clipboard.min.js"></script>
    <script src="./assets/js/counter/jquery.waypoints.min.js"></script>
    <script src="./assets/js/counter/jquery.counterup.min.js"></script>
    <script src="./assets/js/counter/counter-custom.js"></script>
    <script src="./assets/js/custom-card/custom-card.js"></script> 
    <!-- <script src="./assets/js/dashboard/default.js"></script> -->
    <!-- <script src="./assets/js/notify/index.js"></script> -->
    <script src="./assets/js/greeting.js"></script>
    
    <script src="../mobile-customers/js/owl.carousel.min.js"></script>

    <script src="../mobile-customers/app.0.0.11.js"></script>
    <script src="../mobile-customers/js/sweetalert.js"></script>
    <!-- Plugins JS Ends-->
    <!-- Theme js--> 
    <script src="./assets/js/script.js"></script>
    <!-- login js-->
<?php if(isset($_SESSION['msg'])){ unset($_SESSION['msg']);} ?>

<script src="https://js.paystack.co/v1/inline.js"></script>

<script>
    const paymentForm = document.getElementById('paymentForm');
    paymentForm.addEventListener("submit", payWithPaystack, false);
    function payWithPaystack(e) {
    e.preventDefault();
    let handler = PaystackPop.setup({
        key: '<?php echo $paystackPublic ?>', // Replace with your public key
        email: document.getElementById("email-address").value,
        amount: document.getElementById("amount").value * 100,
        ref: 'CCI Traders-<?php echo $ref ?>',  
        onClose: function(){
        // alert('Window closed.');
        },
        callback: function(response){
        // let message = 'Payment complete! Reference: ' + response.reference;
        // alert(message);
            // console.log(response)
            const amount = document.getElementById("amount").value;
            $.ajax({
                url: 'verify_transaction?reference='+ response.reference+'&amount='+amount,
                method: 'get',
                success: function (response) {
                // the transaction status is in response.data.status
                window.location.reload();
                }
            });
        }
    });
    handler.openIframe();
    }
</script>