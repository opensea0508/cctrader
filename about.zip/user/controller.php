<?php

require './clean.php';
$code = bin2hex(random_bytes(12));
$email = $_SESSION['email'];
$userid = $_SESSION['userid'];
$folder = 'files';

require '../image_php/class.upload.php';
$transid = date("Ymdhis");
$filePath = "../image_php/image_doc.php";



//start and stop trade
if(isset($_POST['startTrade'])){ 
    $link = clean($_POST['link']);
    $request = clean($_POST['request']);
    $type = $link =="start-trade"?'start':'stop';
    $date = gmdate("Y-m-d H:i:s", strtotime("+1 hour"));


    $sql = runQuery("INSERT INTO dtrade_request SET userid='$userid', demail='$email', drequest='$request', dtype='$type', ddate='$date' ");
    if($sql){
        $_SESSION['msg']='<div class="alert alert-success" role="alert">
                <strong>Success!</strong> <br>
                Submitted successfully! please don\'t submit the form again.
            </div>';
        }else{
            $_SESSION['msg']='<div class="alert alert-danger" role="alert">
                <strong>Fail!</strong> <br>
                Oops! unable to submit your request, try again later!
            </div>'; 
        }
        
        header("Location:$link");
 

}
    
    
    
    //KYC
if(isset($_POST['saveKyc'])){ 

    $occupation = clean($_POST['occupation']);
    $annual = clean($_POST['annual']);
    $monthly = clean($_POST['monthly']);
    $funds = clean($_POST['funds']);
    $employment = clean($_POST['employment']);
    $exp = clean($_POST['exp']);
    $specify = clean($_POST['specify']);
    $goal = clean($_POST['goal']);
    $qty = clean($_POST['qty']);
    $app = clean($_POST['app']);
    $leverage = clean($_POST['leverage']);
    $position = clean($_POST['position']);
    $risk = clean($_POST['risk']);

    $sql= runQuery("INSERT INTO dkyc SET userid='$userid', demail='$email', doccupation='$occupation', dannual='$annual', dmonthly='$monthly', dfunds='$funds', demployment='$employment', dexperience='$exp', dspecify='$specify', dgoal='$goal', dqty='$qty', dapp='$app', dleverage='$leverage', dposition='$position', drisk='$risk', ddate=NOW() ");

    if($sql){
        $_SESSION['msg']='<div class="alert alert-success" role="alert">
                <strong>Success!</strong> <br>
                Submitted successfully! please don\'t fill the form again.
            </div>';
        }else{
            $_SESSION['msg']='<div class="alert alert-danger" role="alert">
                <strong>Fail!</strong> <br>
                Oops! unable to submit your kyc, try again later!
            </div>'; 
        }
        
        header("Location:kyc");

}







//Upload Documents
if(isset($_POST['upDocs'])){ 
      runQuery("UPDATE dregister SET dvstatus='submitted' WHERE userid='$userid' and demail='$email' ");
     if(!empty($_FILES['img']['name'])){
         insertImagesNew($_FILES['img'], $code, 'dutility');
         @unlink($_POST['himg']);
     } 

     if(!empty($_FILES['img1']['name'])){
      insertImagesNew($_FILES['img1'], $code, 'dfront', '_1');
      @unlink($_POST['himg1']);
      }

      if(!empty($_FILES['img2']['name'])){
        insertImagesNew($_FILES['img2'], $code, 'dback', '_2');
        @unlink($_POST['himg2']);
        }
  
        $_SESSION['msg']='<div class="alert alert-success" role="alert">
                <strong>Success!</strong> <br>
                Updated successful!
            </div>';
        header("Location:verification");

}


//Bank Detail
if(isset($_POST['saveBank'])){
    $bank = clean($_POST['bank']);
    $name = clean($_POST['name']);
    $number = clean($_POST['number']);
    $country = clean($_POST['country']);
    $sort = clean($_POST['sort']);
    runQuery("UPDATE dregister SET dbank='$bank', daccName='$name', daccNum='$number', dcountry='$country', dsort='$sort' WHERE userid='$userid' and demail='$email' ");
    $_SESSION['msg']='<div class="alert alert-success" role="alert">
            <strong>Success!</strong> <br>
            Updated successful!
        </div>';
    header("Location:profile");
}


//Profile Details
if(isset($_POST['saveProf'])){
    $fname = clean($_POST['fname']); 
    $city = clean($_POST['city']);
    $state = clean($_POST['state']);
    $address = clean($_POST['address']);
    $waddress = clean($_POST['waddress']);
    $nphone = clean($_POST['nphone']);
    $kin = clean($_POST['kin']); 
    $rel = clean($_POST['rel']); 

   $sql = runQuery("UPDATE dregister SET dfname='$fname', dcity='$city', dstate='$state', daddress='$address', dwalletAddress='$waddress', dnext='$kin', drelation='$rel', dnextPhone='$nphone' WHERE demail='$email' AND userid='$userid' ");
    if($sql){
        $_SESSION['msg']='<div class="alert alert-success" role="alert">
        <strong>Success!</strong> <br>
        Updated successful!
    </div>';
    }else{
        $_SESSION['msg']='<div class="alert alert-danger" role="alert">
                    <strong>Fail!</strong> <br>
                    Oops! something went wrong, try again later!
                </div>';
    }

    header("Location:profile");

}