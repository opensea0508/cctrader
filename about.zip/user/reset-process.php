<?php
require './clean.php';

if($_SERVER['REQUEST_METHOD']=="POST"){
   
}
