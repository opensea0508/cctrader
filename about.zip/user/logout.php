<?php
require 'clean.php';
logoutUser();
