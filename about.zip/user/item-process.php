<?php
// require 'clean.php';

$item = '../mobile-customers/item';
include '../mobile-customers/image_php/class.upload.php';
$folder = "../mobile-customers/image_php/image_author.php";

include '../mobile-customers/item-process-api.php';
