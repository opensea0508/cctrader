<div class="card" >
                <div class="card-body ">
                    <h3 class="">Wallet Balance</h3>
                    <h4 class="">$<?php echo (userInfo($user, $email, 'dwallet')!=0)? number_format(userInfo($user, $email, 'dwallet')):'0.00' ?></h4>
                    <hr>
                    <p><b>Wallet Adrress:</b> <?php echo userInfo($user, $email, 'dwalletAddress')  ?></p>
                </div>
                </div>

<!-- <div class="card">
                          <div class="card-body">
                              
                          

                          <div class="main-navbar lister"> 
                            <div id="mainnav">
                                <ul class="nav-menu custom-scrollbar">
                                
                                 
                                <li class="dropdown"><a class="nav-link menu-title link-nav" href="my-trips">
                                    <i class="fa fa-truck"></i>
                                    <span >Delivery History</span></a></li> 

                                <li class="dropdown"><a class="nav-link menu-title link-nav" href="wallet">
                                <i class="fa fa-briefcase"></i><span> Wallet </span></a></li> 

                                <li class="dropdown"><a class="nav-link menu-title link-nav" href="chat"><i class="fa fa-comment"> </i><span>Message(0)</span></a></li> 

                                <li class="dropdown"><a class="nav-link menu-title link-nav" href="promo"><i class="fa fa-gift"></i><span>Promo & Discount</span></a></li> 
 
                                <li class="dropdown"><a class="nav-link menu-title link-nav" href="../contact?report=Report An Issue"><i class="fa fa-bug"> </i><span>Report An Issue</span></a></li>
                                
                                
                                </ul>
                            </div>
                             
                            </div>





                          </div>
                      </div> -->