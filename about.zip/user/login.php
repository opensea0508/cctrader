<?php include 'head.php' ?>
  <body>
    
    <!-- page-wrapper Start-->
    <div class="container-fluid">
      <div class="row">
        <div class="col-xl-5"><img class="bg-img-cover bg-center" src="./assets/images/login/3.jpg" alt="looginpage"></div>
        <div class="col-xl-7 p-0">
          <div class="login-card">
            <form class="theme-form login-form needs-validation" novalidate="" action="login-process" method="POST">
                <?php echo isset($_SESSION['msg'])? $_SESSION['msg']: '' ?>
              <div class="login-header text-center">
                <h4>Login</h4>
                <h6>Welcome back! Log in to your account.</h6>
              </div>
              <div class="form-group">
                
              </div>
              <div class="login-social-title">                
                <h5>Sign in with Email</h5>
              </div>
              <div class="form-group">
                <label>Email Address</label>
                <div class="input-group"><span class="input-group-text"><i class="fa fa-envelope text-orange"></i></span>
                  <input class="form-control" type="email" name="email" required="" placeholder="Test@gmail.com">
                  <div class="invalid-tooltip">Please enter proper email.</div>
                </div>
              </div>
              <div class="form-group">
                <label>Password</label>
                <div class="input-group"><span class="input-group-text"><i class="fa fa-lock text-orange"></i></span>
                  <input class="form-control" type="password" name="pass" required="" placeholder="*********">
                  <div class="invalid-tooltip">Please enter password.</div>
                  <div class="show-hide"><span class="show">  </span></div>
                </div>
              </div>
              <div class="form-group">
                <div class="checkbox">
                  <!-- <input id="checkbox1" type="checkbox"> -->
                  <!-- <label class="text-muted" for="checkbox1">Remember password</label> -->
                </div>
                <a class="link" href="forget-password">Forgot password?</a>
              </div>
              <div class="form-group">
                <button name="save" class="btn btn-block w-100 text-white bg-orange" type="submit">Sign in</button>
              </div>
              <p>Don't have account?<a class="ms-2" href="register">Create Account</a></p>
            </form>
          </div>
        </div>
      </div>
    </div>
    <script>
      (function() {
      'use strict';
      window.addEventListener('load', function() {
      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      var forms = document.getElementsByClassName('needs-validation');
      // Loop over them and prevent submission
      var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
      if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
      }
      form.classList.add('was-validated');
      }, false);
      });
      }, false);
      })();
    </script>
   
   <?php include 'script.php' ?>
    <!-- login js-->
    <!-- Plugin used-->
  </body>
 
</html>