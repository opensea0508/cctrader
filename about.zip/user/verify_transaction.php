<?php

require 'clean.php'; 


$email = $_SESSION['email'];
$customerId = $_SESSION['code'];

$transid = bin2hex(random_bytes(11));

$refrence = $_GET['reference'];
$amount = $_GET['amount'];
// die;
    //check if payment was successfull
    $result = array();
    //The parameter after verify/ is the transaction reference to be verified
    $payrefrence=$_SESSION['transid'];
    $url = 'https://api.paystack.co/transaction/verify/'.$refrence;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt(
        $ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer '.$paystackPrivate]
    );
    $request = curl_exec($ch);
    curl_close($ch);
    
    if ($request) {
        $result = json_decode($request, true);
    }

    $date = gmdate("Y-m-d H:i:s", strtotime("+1 hour"));
 
    if (array_key_exists('data', $result) && array_key_exists('status', $result['data']) && ($result['data']['status'] === 'success')) {
        //update database and set user payment
        //get wallet balance and add to it
        $row = runQuery("SELECT customer_wallet FROM dcustomers WHERE customer_code='$customerId' AND demail='$email' ")->fetch_assoc();
        $wall = (Float)$row['customer_wallet'] + (Float)$amount;
        runQuery("UPDATE dcustomers SET  customer_wallet='$wall' WHERE customer_code='$customerId' AND demail='$email' ");


        runQuery("INSERT INTO dtransaction_history SET customer_code='$customerId', transaction_id='$transid', dname='Wallet topup', amount='$amount', dcredit='$amount', dwallet_balance='$wall', ddate='$date', dstatus='customer', demail='$email'");
  
    }
    else{

        $_SESSION['msg']="Your payment was not successful!";
    }


 
?> 